package com.example.weatherapi.models

class Main {
}